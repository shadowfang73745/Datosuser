package com.example.datosuser;

import android.os.Bundle;

public abstract class information {
    protected abstract void onCreate(Bundle savedInstanceState);
}
